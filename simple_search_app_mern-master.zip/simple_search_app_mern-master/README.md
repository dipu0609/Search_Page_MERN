## Simple Search App with MERN

### Initial UI on page load

<br />
<img height="400" src="./images/initial_view.png" alt="Initial view" />

<br />

### Searched with a keyword

<br />
<img height="400" src="./images/searched_view.png" alt="Searched view" />
